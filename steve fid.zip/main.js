function visit(s){
  window.open(`https://steve-fid.itch.io/`+s,null,null,false)
}